
"use strict";

let Speed = require('./Speed.js');
let Num = require('./Num.js');

module.exports = {
  Speed: Speed,
  Num: Num,
};
